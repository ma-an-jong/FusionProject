package Server;

import org.apache.ibatis.session.SqlSessionFactory;
import persistence.DTO.*;
import persistence.DAO.*;
import persistence.MyBatisConnectionFactory;

import java.io.*;
import java.net.Socket;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ServerThread extends Thread {
    private static final int TYPE_DEFINED = 1;

    private Connection jdbcConn; //JDBC 연결
    private SqlSessionFactory sqlSessionFactory; //MYBATIS 연결

    private Socket socket;
    private BufferedReader in = null;
    private BufferedWriter out = null;

    public ServerThread(Socket socket)
    {
        this.socket = socket;

        //TODO: DB 연결 2번해야 되는구만.... MYBATIS + JDBC
        jdbcConn = JDBCConnection.getConnection(JDBCConnection.url);
        sqlSessionFactory =  MyBatisConnectionFactory.getSqlSessionFactory();
        System.out.println("서버 Thread 생성");
    }

    @Override
    public void run()
    {
        try
        {
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
        }
        catch(IOException e)
        {
            e.printStackTrace();
            System.out.println("SocketBuffer 가져오기 실패");
        }

        // TODO: 로그인 정보 요청
        
        boolean flag = true;
        while (flag)
        {
            Protocol protocol;
            String packetType;

            try
            {
                packetType = in.readLine();
                protocol = new Protocol(packetType);
            }
            catch (IOException e)
            {
                System.out.println("버퍼 readline 실패");
                continue;
            }

            //case문 시작
            switch (packetType)
            {
                case Protocol.PT_EXIT: // 프로그램 종료 수신
                {
                    writePacket(Protocol.PT_EXIT);
                    flag = false;
                    System.out.println("서버종료");
                    break;
                }
                case Protocol.PT_REQ_LOGIN:
                {
                    System.out.println("클라이언트가 로그인 정보를 보냈습니다.");
                    String id;
                    String password;

                    id = protocol.getId();
                    password = protocol.getPassword();

                    UserDAO userDAO = new UserDAO(jdbcConn);
                    List<UserDTO> userList = userDAO.selectAllUser();

                    for(UserDTO dto : userList)
                    {
                        if(dto.getId() == id && dto.getPassword() == password )
                        {
                            if(dto.getCategory() == 'a')
                            {
                                writePacket(Protocol.PT_LOGIN_RESULT + Protocol.splitter+"1");
                            }
                            else if(dto.getCategory() == 's')
                            {
                                writePacket(Protocol.PT_LOGIN_RESULT + Protocol.splitter+"2");
                            }
                            else if(dto.getCategory() == 'p')
                            {
                                writePacket(Protocol.PT_LOGIN_RESULT +Protocol.splitter +"3");
                            }
                            else
                            {
                                System.out.println("unsupported");
                            }
                            System.out.println("로그인 성공");
                            break;
                        }

                    }
                    writePacket(Protocol.PT_LOGIN_RESULT +Protocol.splitter +"4");
                    System.out.println("일치하는 id/password가 없습니다");
                    break;
                }
                case Protocol.PT_REQ_SENDFILE:
                {

                    break;
                }
                case Protocol.PT_REQ_FILE:
                {
                    break;
                }

                //본인의 카테고리까지 전송하는걸로
                case Protocol.CS_REQ_PERSONALINFO_VIEW:
                {
                    char category = protocol.getCategory();
                    String key = protocol.getKey();

                    if(category == 's')
                    {
                        StudentDAO studentDAO = new StudentDAO(jdbcConn);
                        StudentDTO dto = studentDAO.searchByStudent_code(key);

                        if(dto !=null)
                        {
                            String data = Protocol.SC_RES_PERSONALINFO_VIEW;
                            data+=dto.getSname() + Protocol.splitter;
                            data += dto.getDepartment() + Protocol.splitter;
                            data += dto.getPhone() + Protocol.splitter;
                            data += dto.getGrade();
                            writePacket(data);
                        }
                        else
                        {
                            System.out.println("해당 정보를 찾을수 없습니다.");
                            break;
                        }
                    }
                    else if(category == 'p')
                    {
                        ProfessorDAO professorDAO = new ProfessorDAO(jdbcConn);
                        ProfessorDTO dto = professorDAO.searchByProfessor_code(key);

                        if(dto !=null)
                        {
                            String data = Protocol.SC_RES_PERSONALINFO_VIEW + Protocol.splitter;
                            data += dto.getPname() + Protocol.splitter;
                            data += dto.getDepartment() + Protocol.splitter;
                            data += dto.getPhone();
                            writePacket(data);
                        }
                        else
                        {
                            String data = Protocol.SC_RES_PERSONALINFO_VIEW;
                            System.out.println("해당 정보를 찾을수 없습니다.");
                            break;
                        }

                    }
                    else
                    {
                        System.out.println("잘못된 카테고리");
                        break;
                    }


                }


            }
        }

        }

    //방법론
    public void writePacket(String source)
    {
        try
        {
            out.write(source + "\n");
            out.flush();
        }
        catch (IOException e)
        {
            e.printStackTrace();
            System.out.println("write에 실패하였습니다.");
        }
    }

}
